<?php 
 
 $con = mysqli_connect("localhost","root","","test_db") or die("Couldn't connect");

?>