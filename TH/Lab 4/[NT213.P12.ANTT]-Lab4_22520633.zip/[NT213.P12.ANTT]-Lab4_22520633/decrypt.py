from Crypto.Cipher import AES
import base64

# Khóa và vectơ khởi tạo (IV)
key = b'This is the super secret key 123'
iv = b'\x00' * 16

# Chuỗi đã được mã hóa
cipher_text = 'DTrW2VXjSoFdg0e61fHxJg='
# Giải mã chuỗi
cipher_bytes = base64.b64decode(cipher_text)
cipher = AES.new(key, AES.MODE_CBC, iv)
plain_bytes = cipher.decrypt(cipher_bytes)
plain_text = plain_bytes.decode('utf-8').strip('\0')

print(plain_text)
